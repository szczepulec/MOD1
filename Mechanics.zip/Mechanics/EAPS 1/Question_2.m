clear;
close all;
clc;
% Mixture composure

    mass_gold = 3.2e-3; % kg
    mass_iron = 8.9e-3; % kg
    density_gold = 19300; % kg/m3
    density_iron = 7850; % kg/m3
    %calculating volumes of gold and iron
    volume_gold = mass_gold / density_gold; % m3
    volume_iron = mass_iron / density_iron; % m3
        %calculating total density
        total_volume = volume_gold + volume_iron; % m3
        total_mass = mass_gold + mass_iron; % kg
        total_density = total_mass/ total_volume; % kg/m3

    % adding aluminium
    mass_alu = 12.3e-3; %kg
    density_alu = 2702; % kg/m3
    volume_alu =  mass_alu / density_alu ; % m3
    
        %calculating total density with aluminium
        total_volume_v2 = volume_gold + volume_iron + volume_alu; % m3
        total_mass_v2 = mass_gold + mass_iron + mass_alu; % kg
        total_density_v2 = total_mass/ total_volume; % kg/m3
    