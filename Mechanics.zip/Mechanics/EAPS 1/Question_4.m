clear; 
close all;
clc;


x = 17 + 3*(rand(1,1000)*2-1) ;

y = 17 + 3*randn(1,1000); %standard deviation
histogram(x);
figure;
histogram(y);