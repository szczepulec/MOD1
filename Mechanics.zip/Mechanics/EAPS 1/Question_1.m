clear;
close all;
clc;


 x = sqrt(log2(87)) *((exp(1)^pi)/(cosd(23.7)))
 