clear;
close all;
clc;
%calculating for observer A
 A = [153, 142, 164, 133, 149, 146]; % data of observer A in secounds
       
       mean_ObserverA = mean(A,'all'); 
       std_ObserverA = std(A); 
       N_ObserverA = length(A); %number of measurements
       std_meanA = std_ObserverA / sqrt(N_ObserverA);  %standard deviation of the mean
       
%calculating for observer B    
B = [153, 153, 141, 149, 148, 156, 160, 161, 141, 150, 137, 138, 149, 165]; % data of observer b in secounds

       mean_ObserverB = mean(B,'all'); 
       std_ObserverB = std(B); 
       N_ObserverB = length(B); %number of measurements
       std_meanB = std_ObserverB / sqrt(N_ObserverB);  %standard deviation of the mean
       
% printing output       
fprintf('Observers A mean: %.1f [s] ± %.1f [s] (%%68 CI) \n', mean_ObserverA, std_meanA);       
fprintf('Observers B mean: %.1f [s] ± %.1f [s] (%%68 CI) \n', mean_ObserverB, std_meanB);
            
  