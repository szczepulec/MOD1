clear;
close all;
clc;
%array of 0.9s and 2.3s
x =[ zeros(1,256) + 0.9,zeros(1,256) + 2.3];
sum_X = sum(x);

%array of 77 values between 200 and 400

K = linspace(200,400,77);
sum_K = sum(K);
