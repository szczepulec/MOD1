clear;
close all;
clc;

    T = [16.9 18.0 18.6 19.1 19.5 18.1 16.5 17.3 16.3 20.4 17.4 18.7];
    mean_temperature = mean(T,'all');
    standard_deviation = std(T);
    N_t = length(T); %number of measurements
    std_mean =  standard_deviation / sqrt(N_t); %standard deviation of the mean
 
 %  fprintf('mean temperature : %.2f\n', mean_temperature');
  % fprintf('standard deviation : %.2f\n',  standard_deviation');
   %fprintf('standard deviation of the mean : %.2f\n',   std_mean');
   % idk if %%68 is correct
  fprintf('mean temperature : %.1f ± %.1f (%%68 CI)', mean_temperature, std_mean );
