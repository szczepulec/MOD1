%I have decided that the triangle starts from 0 row  = 1 because the
%polinomial coeffitient of (x+y)^0 = 1 and (x+y)^1 = 1x + 1y  
function [row] = getPascalRow(n)
if n == 0 % case for row number 0 
    row = 1;
elseif n == 1 % case for row number 1 
    row = [1 1];
else  % case for row number n
    row = [1,1]; 
    for temp = 2:n
        row = [getPascalRow(temp-1),0] + [0,getPascalRow(temp-1)]; % recursion 
    end
end
end