clear
close all;
clc;

Q = [4.9, 6.7, 3.8, 5.6, 5.2, 2.6, 4.9, 3.1, 6.7, 4.2, 6.9, 3.6, 5.2, 4.2, 1.1, 2.7, 5.3, 4.2, 2.5, 3.3];

M = mean (Q);

% fing h
h_2 = M/(0.0141625 * pi *15.3);

% Error 0.2C
h_1 = sqrt(0.2^2+0.2^2);

% Error CL95%
P = std (Q);
C = 2.093 * P/sqrt(20);

% Error A%
%Assume error for cylinder is 0.05mm
A_1 = 2*pi*(0.00005/0.0275+0.00005/0.23)*0.0275*0.23 ;
A_2 = 2*pi*(2*0.00005/0.0275)*0.0275^2 ;
A_T = A_1 + A_2 ;
% total error
h_T = h_2*(sqrt(((C/M)^2)+((h_1/15.3)^2)+((A_T/0.0141625)^2)));

fprintf('h = %.3f ± %.3f W/(m^2 K)',h_2,h_T);


