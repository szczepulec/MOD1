function [Number] = getFibNumberRecursion(n)
if n == 0
    Number = 1;
elseif n == 1
    Number = 1;
else
    for temp = 2:n
        Number = getFibNumberRecursion(temp-1) + getFibNumberRecursion(temp-2);
    end
end
