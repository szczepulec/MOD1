close all;
clear;
clc;
% part A - yolo jump

y_0 = 3000; % Initial condition
delta_t= 0.01;
N = 3000; % Perform this many steps
ddy = zeros(1,N);
y = zeros(1,N); % Initialize arrays
dy = zeros(1,N);
time = zeros(1,N);
m = 67; % constants
g = 9.81;
cD = 0.023;
y(1) = y_0;
for k = 1 : N-1 % loooooop
   
 ddy(k+1) = cD/m *(dy(k))^2 - g ;
dy(k+1) = dy(k) + delta_t * ddy(k+1);
y(k+1) = y(k) + delta_t * dy(k+1);
time(k+1) = time(k) + delta_t;
    
end

plot(time, y, '.');

% it will take 29.1 secounds to crush without parashute final velosity is
% 160 m/s - it never gets to terminal velocity in this time it will take
