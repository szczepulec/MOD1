function [Number] = getFibNumberIteration(n)
if n == 0
    Number = 1;
elseif n == 1
    Number = 1;
else
    a = 1 ;
    b = 1 ;
    for temp = 2:n
        Number = a + b ;
        b = a ;
        a = Number;
    end
end
end