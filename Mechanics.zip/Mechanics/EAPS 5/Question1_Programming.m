clear ; 
close all; 
clc;

tic 
getFibNumberIteration(10)
toc
tic
getFibNumberRecursion(10)
toc
% so Iteration is muuch faster. When I plug n = 100 iteration took
% fractions if seconds and recursion failed to compute. It is such because
% recursion runs function from the beguining, so it also does  every command that are in the function ,(the if
% statemants in this case) not only the loop itself. It creates a new
% instance of the memory and creates a new process that does every function
% on the way.
% Recursion approach also uses much more memory, because it stores all the
% values of the function in between because they are required for the final
%finction. Iteration aproach only stores 4 integer variables no matter how
%big the function is. All above are the reasons why recursion takes much
%longer and shuld be avoided in my opinion :). 