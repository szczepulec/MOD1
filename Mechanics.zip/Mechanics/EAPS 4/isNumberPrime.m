function output = isNumberPrime(n)
temp = mod(n,2);
if n==1 || n==-1
    output=0;
elseif temp==0
    output=0;
elseif n==2 || n==-2
    output=1;
elseif temp>0
    for m = 3:2:sqrt(abs(n))
        temp = mod(n,m);
        if temp==0
            output=0;
            return
        end
    end
    output=1;
end
end
