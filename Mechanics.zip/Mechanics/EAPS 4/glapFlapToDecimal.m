function output = glapFlapToDecimal(input)
output = 0;
digits =floor(log10(input)) + 1; % converting a intiger to an array
      if input >= 0
              array = zeros();
          for temp=digits:-1:1
              array(1,digits+1-temp) = floor(input/(10^(temp-1)));
              input = mod(input,10^(temp-1));
          end
      end
      x = flip(array); % flip it so it works 
     for temp = 0:numel(x)-1
         output = output + x(temp+1)*9^temp;% changing the numerical system
         
     end