function r = isDivisible(x, y)
if mod(x,y) == 0
    r = 1;
else
    r = 0;
end
end