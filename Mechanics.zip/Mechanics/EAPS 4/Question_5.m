clear;
close all;
clc;

y_0 = 220; % Initial condition
delta_t= 0.01;
N = 10000; % Perform this many steps
y = zeros(1,N); % Initialize arrays
time = zeros(1,N);
B = -0.0047; 
C = 7.2;
y(1) = y_0;
for k = 1 : N-1 % loooooop
dydt = B * y(k) * sqrt(y(k)) + C;
y(k+1) = y(k) + delta_t * dydt;
time(k+1) = time(k) + delta_t;
end
plot(time, y, '.');