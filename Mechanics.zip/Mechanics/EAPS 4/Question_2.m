clear;
close all;
clc;


A = 54986; % value of A we want to know A BC values

container = A - 1; %change indexing to make it easier

BC_values = zeros(1,container); % this will contain all B+C values for which B*C = A
C = 0;
b = 0;

for B = 2:A
    b = B-1;
    if mod(A,B) == 0 % B is a divisor of A
        C = A/B;
        BC = B + C;
        BC_values(1,b) = BC; % put result in the array
    else
        BC_values(1,b) = A + 2;% we don't want 0 in the array. A+2 will always be greater than the lowest B+C
    end
end

[val,idx] = min(BC_values); % get position and value of the smallest sum

B = idx + 1; 
C = A/B; 

