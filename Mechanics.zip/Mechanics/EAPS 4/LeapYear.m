function output = LeapYear(x)
a = isDivisible(x,4);
b = isDivisible(x,100);
c = isDivisible(x,400);

if a == 1 && b == 0
    output = 1;
else 
    output = 0;
end
if c == 1
    output = 1;
end
end