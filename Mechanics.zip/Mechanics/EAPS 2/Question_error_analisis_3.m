
clear;
close all;
clc;

% Momentum [kg.m/s]
p = 1.0e-03 * [0.0940, 0.172, 0.153, 0.130, 0.116, 0.0820, 0.150, ...
    0.114, 0.0950, 0.107, 0.106, 0.144, 0.164, 0.127, 0.0810, 0.163, ...
    0.131, 0.121, 0.112, 0.133, 0.147, 0.0950, 0.121, 0.109, 0.144, ...
    0.119, 0.107, 0.0930, 0.148, 0.104, 0.112];

Mean_p = mean(p,'all');%calculating mean
std_p = std(p);
Nb_of_p = length(p);
T = 1.960; %t value taken from the table page 58 for infinity
Error = (T * std_p)/(sqrt(Nb_of_p)); %calculating error

fprintf('Momentum = %.6f ± %.6f  [kg*m/s] (CI95%%) %n',Mean_p,Error);

