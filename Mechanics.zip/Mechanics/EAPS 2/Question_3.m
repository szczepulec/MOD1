clear;
close all;
clc;
D = 20; %number of sides the dice has

% throw = ceil(D* rand()); <---- line of code to do the throwing of a die

throw = ceil(D* rand());

counter = 1; % counting how many thorws it took to get a 20

while throw ~= 20
    throw = ceil(D* rand());
    counter = counter + 1;
end

fprintf('it took %d thorws to get a 20!', counter);