clear;
close all;
clc;
%values in m
width = 37.20/100;
width_error = 0.05/100;
height = 105.80/100;
height_error = 0.05/100;
length = 49.55/100;
length_error = 0.05/100;
%values in kg
mass = 376.0;
mass_error = 2.0;

%formula for density
density = mass/(width * height * length); % density in kg/cm

%calculating error
density_error = density * sqrt((width_error/width)^2 + (height_error/height)^2 + (length_error/length)^2 + (mass_error/mass)^2);

fprintf('density = %.1f ± %.2f [kg/m3]%n (CI95%%)', density, density_error);