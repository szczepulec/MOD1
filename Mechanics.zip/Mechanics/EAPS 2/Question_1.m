clear;
close all;
clc;

n = 0;
for temp1 = 1:99
    
    n = n + temp1;
end
fprintf('this sum equals = %.1f', n);

m = 1;

for temp2 = 1:25
    m = m * temp2;
end