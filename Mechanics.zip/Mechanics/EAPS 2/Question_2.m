clear;
close all;
clc;
%v possible error range -0.28 +0.38
v = linspace(0.28, 0.38, 30);
%b possible error range -0.49 +0.65
b = linspace(0.49, 0.65, 30);
%empty array to allocate storage space :)
F = zeros(1,99);

counter = 1; %just a counter

%calculating  function F = (a^(-1) + c^(-1))^(-1);

for temp1 = 1:30
    for temp2 = 1:30
        value1 = v(temp1);
        value2 = b(temp2);
        fvalue = (value1^(-1) + value2^(-1))^(-1);
        F(counter) = fvalue;
        counter = counter + 1 ;
    end
end
Fmin = min(F);
Fmax = max(F);
Favg = (Fmin + Fmax) / 2;
%calculating error range
Fplusminus = Fmax - Favg;
fprintf('f = %.2f ± %.2f %n',Favg,Fplusminus);

