clear;
close all;
clc;

%You gave me red pill and now I know how matrix works...


Matrix = ones(25,11);

row = 1;
column = 1;

for row = 1:25
    for column = 1:11
        Matrix(row,column) = column^(row) ;   %making magic with matrix
    end
end