clear;
close all;
clc;

N = 10;   % Test for N = 10 first
eN = 1;   % This will contain the final answer I changed value form 0 to 1 because 0! = 1 and I would like to include that
nfac = 1; % We need to compute ’n!’ along the way

for temp = 1:N
    nfac = nfac*temp;
    eN = eN + 1/nfac;
end
fprintf('this sum is equal to %.5f',eN);