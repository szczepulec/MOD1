clear;
close all;
clc;

f = [4.62, 5.00, 5.45, 5.99, 6.65, 7.48]; % light frequency in 1e14 Hz
U = [0.80, 0.90, 1.20, 1.40, 1.70, 2.00]; % counter potential (Volt)
sf = 0.03; % 10^14 HZ;
sU = 0.05; %V
Ef = f*sf; %calculating error for frequency
EU = U*sU; %calculating error for current potential
errorbar(f, U, Ef,  Ef,EU, EU,'LineStyle','none');
title('Photoelectric effect');
legend('Measured values with errors');
xlabel('Light frequency [1e14 Hz]');
ylabel('Counter potential [V]');
