clear;
close all;
clc;

i_deg = [10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, ]; % Degrees
r_deg = [7.3, 8.5, 12.1, 14.6, 17.7, 19.5, 22.3, 25.4, 26.9, 29.3, 32.8]; % Degrees

i_error_deg = 0.2; % Degrees, possible error
r_error_deg = 1; % Degrees, possible error

i_rad = i_deg * pi / 180; % converting to radians
r_rad = r_deg * pi / 180; % converting to radians

i_error_rad = i_error_deg * pi / 180; % converting to radians
r_error_rad = r_error_deg * pi / 180; % converting to radians

E_i = abs(cos(i_rad)) * i_error_rad; % calculated the error to put on the errorbar graph in rads
E_r = abs(cos(r_rad)) * r_error_rad; % calculated the error to put on the errorbar graph in rads
% calculating sin values for the graph
sin_i = sin(i_rad);
sin_r = sin(r_rad);

errorbar(sin_r, sin_i,E_r,E_r,E_i,E_i,'LineStyle','none');  hold on;
 
% calculating N value
n = sin_i ./ sin_r;
Nmean = mean(n);
line(sin_r, Nmean*sin_r);
