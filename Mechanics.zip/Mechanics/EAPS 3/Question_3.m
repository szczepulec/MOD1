clear;
close all;
clc;

N = 10 ; % how many numbers of this series we want to display
series(1) = 0; % first value of the series
series(2) = 1; % secound value of the series
fprintf('Fibonachi serie of the first %d values ',N);

for temp = 3:N % calculating N'th value of the series
    series(temp) = series(temp-1)+series(temp-2);
end

for temp = 1:N % displaing the series
    fprintf(' %d',series(temp) );
end
