clear;
close all;
clc;

Nthrows = 1000000;% number of throws 
Nhits = 0;% number of hits
Throw  = [0,0];

min = -1;
max = 1;
% r = (max-min).*rand() + min; command for a random number from uniform
% distribution in range min max

% throwing 
for temp = 1:Nthrows
    Throw(1) = (max-min).*rand() + min; %randomizing X position of throw
    Throw(2) = (max-min).*rand() + min; %randomizing Y position of throw
    Distance = sqrt(Throw(1)^2 +  Throw(2)^2);
    if Distance <= 1 
        Nhits = Nhits +1;
    end
end
    Ratio = (4* Nhits)/Nthrows;
    fprintf('with %d throws we got %d hits. Ratio is equal to %.4f. I think its an aproximation of Pi value', Nthrows, Nhits, Ratio); 